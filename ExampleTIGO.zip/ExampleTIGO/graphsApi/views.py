from django.shortcuts import render, get_object_or_404
import requests
import pandas as pd
import matplotlib.pyplot as plt
from graphs.models import Server
from graphs.forms import MyForm
import json
# Create your views here.


def graph_view_api(request):
    select_option = 1
    if request.method == 'POST':
        select_option = request.POST.get('my_list')

    form = MyForm()
    server_id = int(select_option)

    server = get_object_or_404(Server, id=server_id)

    url = 'http://3.92.7.29:8000/getItems/'
    payload = {
        'campo1': 'valor1',
        'campo2': 'valor2',
        'campo3': 'valor3',
        'campo4': 'valor4',
        'campo5': 'valor5'
    }
    json_payload = json.dumps(payload)
    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, data=json_payload, headers=headers)

    data = response.json()
    # columnas = data['columnas']
    # datos = data['datos']
    df = pd.DataFrame(data['datos'], columns=data['columnas'])
    df['date'] = pd.to_datetime(df['date'])

    cant = df.size

    filtro = (df['element'] == 1) & (df['server'] == server_id)
    data_memory = df[filtro]
    create_image(data_memory, 'Grafico de uso de Memoria', 'graphMemoryApi.png')
    cant_mem = data_memory.size

    filtro = (df['element'] == 2) & (df['server'] == server_id)
    data_cpu = df[filtro]
    create_image(data_cpu, 'Grafico de uso de CPU', 'graphCpuApi.png')

    filtro = (df['element'] == 3) & (df['server'] == server_id)
    data_disk = df[filtro]
    create_image(data_disk, 'Grafico de uso de Disco', 'graphDiskApi.png')

    return render(request, 'graphs_api/graph.html',
                  {'origen': select_option,
                   'form': form,
                   'server': server,
                   'cantidad': cant,
                   'cant_mem': cant_mem})


def create_image(data, title, img):
    x = data['date']      # [d.date for d in data]
    y = data['measure']   #[d.measure for d in data]
    plt.clf()
    plt.plot(x, y, color='red', linestyle='--', marker='o')
    plt.legend(['Uso de recursos'])
    plt.style.use('bmh')
    plt.xticks(rotation=30, fontsize=6)
    plt.yticks( fontsize=6)
    # plt.xlabel('Fecha')
    plt.ylabel('Porcentaje', fontsize=6)
    plt.title(title)
    plt.grid(True)
    plt.savefig('image/' + img)
