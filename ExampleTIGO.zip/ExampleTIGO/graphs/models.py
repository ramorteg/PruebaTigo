from django.db import models

# Create your models here.


# class Data(models.Model):
#    x = models.FloatField()
#    y = models.FloatField()


# class DataCaptured(models.Model):
#     server = models.TextField()
#     memory = models.FloatField()
#     cpu = models.FloatField()
#     disk = models.FloatField()
#     date = models.DateTimeField()

#     class Meta:
#         unique_together = (('server', 'date'),)


class Server(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.TextField(max_length=50)
    ip = models.TextField(max_length=25)
    user_name = models.TextField(max_length=25, default='bitnami')
    file_key = models.TextField(max_length=25, default='ClaveAmazon2')

    def __str__(self):
        return self.name


class Element(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.TextField(max_length=50)


class Measure(models.Model):
    date = models.DateTimeField(auto_now=True)
    server = models.ForeignKey(Server, on_delete=models.CASCADE)
    element = models.ForeignKey(Element, on_delete=models.CASCADE)
    measure = models.FloatField()
