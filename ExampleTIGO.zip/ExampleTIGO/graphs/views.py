from django.shortcuts import render, get_object_or_404
# from .models import DataCaptured
from .models import Measure
import matplotlib.pyplot as plt
from .forms import MyForm
from .models import Server

# Create your views here.


def graph_view(request):
    select_option = 1
    if request.method == 'POST':
        select_option = request.POST.get('my_list')

    # server = Server.objects.filter(id=select_option)
    server = get_object_or_404(Server, id=select_option)

    # print(server.ip)

    form = MyForm()
    server_id = select_option
    data_memory = Measure.objects.filter(element_id=1, server_id=server_id).order_by('date')
    create_image(data_memory, 'Grafico de uso de Memoria', 'graphMemory.png')

    data_cpu = Measure.objects.filter(element_id=2, server_id=server_id).order_by('date')
    create_image(data_cpu, 'Grafico de uso de CPU', 'graphCpu.png')

    data_disk = Measure.objects.filter(element_id=3, server_id=server_id).order_by('date')
    create_image(data_disk, 'Grafico de uso de Disco', 'graphDisk.png')

    return render(request, 'graphs/graph.html',
                  {'form': form,
                   'sel': select_option,
                   'server': server})


def create_image(data, title, img):
    x = [d.date for d in data]
    y = [d.measure for d in data]
    plt.clf()
    plt.plot(x, y)
    plt.xticks(rotation=30, fontsize=6)
    plt.xlabel('Fecha')
    plt.ylabel('Porcentaje')
    plt.title(title)
    plt.grid(True)
    plt.savefig('image/' + img)
