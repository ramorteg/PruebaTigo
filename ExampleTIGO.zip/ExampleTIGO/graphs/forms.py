from django import forms
from .models import Server


class MyForm(forms.Form):
    my_list = forms.ModelChoiceField(queryset=Server.objects.all(),
                                     widget=forms.Select(attrs={'class': 'form-control'}))

